package com.belhard.lesson3.arrays.onedimentional;

import java.util.Arrays;

import java.util.Scanner;

public class Task3 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("Out from array min in array");
		System.out.println("Please input the length of array. It must be a positive number");
		int length = in.nextInt();
		if (length < 0) {
			System.out.println("You input a wrong numer. Length <0");
			return;
		}

		int arr[] = new int[length];

		for (int i = 0; i < arr.length; i++) {
			arr[i] = (int) (Math.random() * (length) - 1);
			System.out.print(arr[i] + " ");
		}
		
		System.out.println();

		System.out.print("Without min: ");
		Arrays.sort(arr);
		for (int i = 1; i < arr.length; i++)
			System.out.print(arr[i] + " ");

	}

}
