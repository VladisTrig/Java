package com.belhard.lesson3.arrays.onedimentional;

import java.util.Scanner;

public class Task2 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("The number of negative positive and zero in array");
		System.out.println("Please, input array length. It's must be a positive number");
		int length = in.nextInt();
		if (length <= 0.0) {
			System.out.print("You input a wrong number. Length  <=0");
			return;
		}

		int negative = 0;
		int positive = 0;
		int zero = 0;

		double[] arr = new double[length];

		for (int i = 0; i < arr.length; i++) {
			arr[i] = (double) (Math.random() * (length) - 5);
			System.out.println(" " + arr[i]);

			if (arr[i] < 0) {
				negative++;
			}

			if (arr[i] > 0) {
				positive++;
			}

			if (arr[i] == 0) {
				zero++;
			}

		}

		System.out.println("The number of negative is " + negative);
		System.out.println("The number of positive is " + positive);
		System.out.println("The number of zero is " + zero);
	}
}
