package com.belhard.lesson3.arrays.onedimentional;

import java.util.Scanner;

public class Task1 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("Sum of array elements that are multiples of K");
		System.out.println("Please, input array length. It's must be a positive number");
		int length = in.nextInt();
		if (length <= 0) {
			System.out.print("You input a wrong number. Length  <=0");
			return;
		}
		System.out.println("Please, input K. It's must be a positive number");
		int k = in.nextInt();
		if (k <= 0) {
			System.out.print("You input a wrong number. K  <=0");
			return;
		}
		int sum = 0;
		int[] arr = new int[length];

		for (int i = 0; i < arr.length; i++) {
			arr[i] = (int) (Math.random() * (length));
			System.out.println(" " + arr[i]);

			if (arr[i] % k == 0) {
				sum = sum + arr[i];
			}
		}

		System.out.println("Sum of array elements that are multiples of K = " + sum);
	}
}
