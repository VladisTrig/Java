package com.belhard.lesson3.arrays.sorting;

import java.util.Scanner;

public class Task1 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("Bubble sort");
		System.out.println("Please input the length of one-dimensional array. It must be a positive number");
		int length = in.nextInt();

		if (length < 0) {
			System.out.println("You input a wrong numer. Length =<0");
			return;
		}

		int arr[] = new int[length];

		for (int i = 0; i < arr.length; i++) {
			System.out.print("[");
			arr[i] = (int) (Math.random() * length);
			System.out.print("  " + arr[i]);

			System.out.print("]");

		}

		for (int j = 0; j < arr.length-1; j++) {
			
			if (arr[j] < arr[j + 1]) {
				arr[j] = arr[j + 1];
				System.out.println(arr[j]);
			
		
				
				
	} else {
			System.out.print("STOP");

			return;
			}

//			System.out.print("Array after Bubble sort");

	
	}
}
}


