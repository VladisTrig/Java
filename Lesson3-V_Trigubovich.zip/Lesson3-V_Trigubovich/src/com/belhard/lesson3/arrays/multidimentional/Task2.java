package com.belhard.lesson3.arrays.multidimentional;

import java.util.Arrays;
import java.util.Scanner;

public class Task2 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("Sort array in line");
		System.out.println("Please input the number of colomn of array. It must be a positive number");
		int colomn = in.nextInt();

		if (colomn < 0) {
			System.out.println("You input a wrong numer. Colomn =<0");
			return;
		}

		System.out.println("Please input the number of lines of array. It must be a positive number");
		int line = in.nextInt();
		if (line < 0) {
			System.out.println("You input a wrong numer. Lines =<0");
			return;
		}

		int arr[][] = new int[line][colomn];

		for (int i = 0; i < arr.length; i++) {
			System.out.print("[");
			for (int j = 0; j < arr[i].length; j++) {
				arr[i][j] = (int) (Math.random() * (colomn + line));
				System.out.print(" " + arr[i][j]);

			}
			System.out.println("]");
		}

		System.out.println(
				"If you want to sort array Ascending, input 1; to sort Descending, input any number with the exception of 1");
		int choice = in.nextInt();

		if (choice == 1) {

			System.out.println("Sorted array: ");

			for (int i = 0; i < arr.length; i++) {
				Arrays.sort(arr[i]);
			}

			for (int lin = 0; lin < arr.length; lin++) {
				System.out.print("[");
				for (int col = 0; col < arr[lin].length; col++)
					System.out.print(arr[lin][col] + " ");
				System.out.println("]");

			}

		} else {
			System.out.println("Sorted array: ");

			for (int i = 0; i < arr.length; i++) {
				Arrays.sort(arr[i]);
			}
			for (int lin = 0; lin < arr.length; lin++) {
				System.out.print("[");
				for (int col = arr[lin].length - 1; col >= 0; col--) {
					System.out.print(arr[lin][col] + " ");

				}
				System.out.println("]");

			}

		}
	}
}
