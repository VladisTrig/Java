package com.belhard.lesson3.arrays.multidimentional;

import java.util.Arrays;

import java.util.Scanner;

public class Task1 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("Two-dimensional array in matrix");
		System.out.println("Please input the number of colomn of array. It must be a positive number");
		int colomn = in.nextInt();
		if (colomn < 0) {
			System.out.println("You input a wrong numer. Colomn =<0");
			return;
		}

		System.out.println("Please input the number of Lines of array. It must be a positive number");
		int line = in.nextInt();
		if (line < 0) {
			System.out.println("You input a wrong numer. Lines =<0");
			return;
		}

		int arr[][] = new int[line][colomn];
		
		for (int i = 0; i < arr.length; i++) {
			System.out.print("[");
			for (int j = 0; j < arr[i].length; j++) {
				arr[i][j] = (int) (Math.random() * (colomn+line));
				System.out.print(" " + arr[i][j]);

			}
			System.out.println("]");
		}
	}
}
