package com.belhard.lesson2.branching;

import java.util.Scanner;

public class Task3 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("Is it triangle?");
		System.out.println("Input the first triangle angle in degrees: ");
		double x = in.nextDouble();
		System.out.println("Input the second triangle angle in degrees: ");
		double y = in.nextDouble();

		if (180 - x - y > 0) {
			System.out.println("It's triangle");
		} else {
			System.out.println("It's not a triangle");
		}

		if (180 - x - y == 90) {
			System.out.println("It's � right triangle");

		}
	}
}
