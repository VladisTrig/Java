package com.belhard.lesson2.branching;

import java.util.Scanner;

public class Task2 {

	public static void main(String[] args) {

		Scanner in = new Scanner(System.in);
		System.out.println("y = x^2-3*x+9 if x<=3; 1/ (x^3+6) if x>3");
		System.out.print("Input x: ");
		double x = in.nextDouble();

		double y;

		if (x <= 3) {
			y = Math.pow(x, 2) - 3 * x + 9;
		} else {
			y = 1 / (Math.pow(x, 3) + 6);
		}

		System.out.println("y = " + y);

	}
}
