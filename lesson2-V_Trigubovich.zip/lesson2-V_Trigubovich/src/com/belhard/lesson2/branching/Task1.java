package com.belhard.lesson2.branching;

import java.util.Scanner;

public class Task1 {

	public static void main(String[] args) {

		Scanner in = new Scanner(System.in);
		System.out.println("max {min1(a;b); min2(c;d)}");
		System.out.print("Input real number a for min1(a;b): ");
		int a = in.nextInt();
		System.out.print("Input real number b for min1(a;b): ");
		int b = in.nextInt();
		System.out.print("Input real number c for min2(c;d): ");
		int c = in.nextInt();
		System.out.print("Input real number d for min2(c;d): ");
		int d = in.nextInt();

		int min1;
		int min2;
		int max;

		if (a > b) {
			min1 = b;
		} else {
			min1 = a;
		}

		if (c > d) {
			min2 = d;
		} else {
			min2 = c;
		}

		if (min1 > min2) {
			max = min1;
		} else {
			max = min2;
		}

		System.out.println("max = " + max);

	}
}
