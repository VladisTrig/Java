package com.belhard.lesson2.linear;

import java.util.Scanner;

public class Task2 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("It's reverse nnn.ddd TO ddd.nnn");
		System.out.print("Input real number of the form nnn.ddd: ");
		double a = in.nextDouble();
		double result = (a * 1000) % 1000 + a / 1000;
		System.out.printf("Your number was reversed: %.3f %n", result);

	}

}
