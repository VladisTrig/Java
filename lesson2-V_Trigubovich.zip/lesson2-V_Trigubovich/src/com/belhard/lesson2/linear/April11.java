package com.belhard.lesson2.linear;

public class April11 {
	int x = 2;

	public int getX() {
		return x;
	}

	public static void main(String[] args) {
		April11 c = new SubClass();
		System.out.println(c.x + " " + c.getX());
	}
}

class SubClass extends April11 {
	int x = 1;

	public int getX() {
		return x;
	}
}

