package com.belhard.lesson2.linear;

import java.util.Scanner;

public class Task4 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		{
			System.out.println("Result = (b + square root (b^2+4ac)) / 2a - a^3c + b^-2");
			System.out.println("Please, Input �");
			double a = in.nextDouble();
			System.out.println("Please, Input b");
			double b = in.nextDouble();
			System.out.println("Please, Input c");
			double c = in.nextDouble();
			double result = 0;

			if ((Math.pow(b, 2) + 4 * a * c) < 0 | a == 0.0) {
				System.out.println("Please try again, eror. Math.pow(b, 2) + 4 * a * c) < 0 or Divide by zero.");
				return;
			} else {
				result = ((b + (Math.sqrt(Math.pow(b, 2) + 4 * a * c))) / (2 * a) - Math.pow(a, 3) * c
						+ Math.pow(b, -2));
			}
			System.out.println("Result = " + result);

		}
	}
}
