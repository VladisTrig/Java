package com.belhard.lesson2.linear;

import java.util.Scanner;

public class Task3 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("It's calculation from 'second's' TO 'hours minutes seconds'");
		System.out.print("Input natural number = second's: ");
		int a = in.nextInt();
		int hh = a / 3600;

		double b = a;
		double c = (b / 3600 - a / 3600) * 60;
		int min = (int) (c);

		double d = a;
		double e = (d / 3600 - a / 3600) * 60 - a / 3600;
		int s = (int) (e);

		System.out.println("result= " + hh + "hh " + min + "min " + s + "s");

	}

}
