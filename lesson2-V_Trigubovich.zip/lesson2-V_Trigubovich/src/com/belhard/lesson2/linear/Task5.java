package com.belhard.lesson2.linear;

import java.util.Scanner;

public class Task5 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		{
			System.out.println("Result = ((sin x + cos y) / (cos x - sin y)) * (tg xy)");
			System.out.println("Please, Input x");
			double x = in.nextDouble();
			System.out.println("Please, Input y");
			double y = in.nextDouble();

			double result = 0.0;
			double a = Math.cos(x) - Math.sin(y);

			if (a == 0) {
				System.out.println("Please try again. Divide by zero.");
				return;
			} else {
				result = ((Math.sin(x) + Math.cos(y)) / (Math.cos(x) - Math.sin(y))) * Math.tan(x * y);
			}

			System.out.println("Result " + result);

		}

	}
}
