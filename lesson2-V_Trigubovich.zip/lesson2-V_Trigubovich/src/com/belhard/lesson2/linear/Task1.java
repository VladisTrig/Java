package com.belhard.lesson2.linear;

import java.util.Scanner;

public class Task1 {

	public static void main(String[] args) {

		Scanner in = new Scanner(System.in);
		System.out.println("z = ((a-3)*b/2)+c");
		System.out.print("Input variable a: ");
		double a = in.nextDouble();
		System.out.print("Input variable b: ");
		double b = in.nextDouble();
		System.out.print("Input variable c: ");
		double c = in.nextDouble();
		double result;
		result = ((a - 3) * b / 2) + c;
		System.out.println("z = " + result);

	}
}