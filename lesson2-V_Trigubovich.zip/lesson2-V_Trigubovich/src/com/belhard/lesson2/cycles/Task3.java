package com.belhard.lesson2.cycles;

public class Task3 {

	public static void main(String[] args) {
		System.out.println("The sum of squares from 1 to 100");

		double a = 1.0;
		double b = 100.0;
		double sum = 0;
		double x;

		for (x = a; x <= b; x++) {
			sum += Math.pow(x, 2);
		}
		System.out.println(sum);
	}
}
