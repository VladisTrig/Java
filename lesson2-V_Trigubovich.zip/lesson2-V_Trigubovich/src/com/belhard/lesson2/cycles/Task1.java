package com.belhard.lesson2.cycles;

import java.util.Scanner;

public class Task1 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("SUM positive integer from 1 to A");
		System.out.print("Input positive integer A:");

		int a = in.nextInt();
		int sum = 0;

		if (a < 1) {
			System.out.println("Error! You input not integer variable");
			return;
		}

		for (int i = 0; i < a; i++) {
			sum += i;
		}
		System.out.println("SUM = " + sum);

	}

}
