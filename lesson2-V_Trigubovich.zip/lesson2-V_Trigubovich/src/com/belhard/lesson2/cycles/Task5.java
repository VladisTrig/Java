package com.belhard.lesson2.cycles;

import java.math.BigInteger;

public class Task5 {

	public static void main(String[] args) {
		System.out.println("The product of squares from 1 to 200");

		BigInteger p = BigInteger.valueOf(1);
		
		for(int x = 2; x <= 200; x++) {
		    p = p.multiply(BigInteger.valueOf((long) x * x));
		}
		
		System.out.println(p);
		
	}
}
