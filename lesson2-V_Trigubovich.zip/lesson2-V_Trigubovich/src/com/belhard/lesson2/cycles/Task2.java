package com.belhard.lesson2.cycles;

import java.util.Scanner;

public class Task2 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println(
				"The length jf the segment. If the length of the segment >2: y = length + 2; else -x*2. Step H");
		System.out.print("Please input the start point of the segment in cm: ");
		double a = in.nextDouble();
		System.out.print("Please input the finish point of the segment in cm: ");
		double b = in.nextDouble();
		System.out.print("Please input the step: ");
		double h = in.nextDouble();

		double y=0;
		double x;

		for (x = a; x <= b; x += h) {
			if (x > 2) {
				y = (x + 4);

			} else {
				y = -x * 2;
			}
		}

		System.out.println(y);
	}
}
