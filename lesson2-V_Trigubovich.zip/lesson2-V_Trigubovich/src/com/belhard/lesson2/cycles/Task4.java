package com.belhard.lesson2.cycles;

import java.util.Scanner;

public class Task4 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("The symbols of ASCII");
		System.out.print("Please input the integer number from 33 to 126: ");
		String a = in.next();

		switch (a) {
		case "33":
			System.out.println(" 33 -> !");
			break;
		case "34":
			System.out.println(" 34 -> '' ");
			break;
		case "35":
			System.out.println("35 -> #");
			break;
		case "36":
			System.out.println("36 -> $");
			break;
		case "37":
			System.out.println("37 -> %");
			break;
		case "38":
			System.out.println("38 -> &");
			break;
		case "39":
			System.out.println("39 -> '");
			break;
		case "40":
			System.out.println("40 -> (");
			break;
		case "41":
			System.out.println("41 -> )");
			break;
		}
	}
}
